﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Models
{
    public class Restaurant
    {

        public Restaurant(int rank)
        {
            Ranking = rank;
        }

        public int Ranking{ get; }
        public string Name { get; set; }
        public string? Dish { get; set; } = "It's all tasty!";
        public string Addr { get; set; }
        public string? Phone { get; set; }
        public string? Link { get; set; } = "Coming soon.";

        public static Restaurant[] GetRestaurants()
        {
            Restaurant r1 = new Restaurant(1)
            {
                Name = "Bombay House",
                Dish = "Any of the curry",
                Addr = "463 N University Ave",
                Phone = "801-373-6677",
                Link = "www.bombayhouse.com"
            };
            Restaurant r2 = new Restaurant(2)
            {
                Name = "Cubby's",
                Dish = "All of them!",
                Addr = "1258 N State St",
                Phone = "801-919-3023",
            };
            Restaurant r3 = new Restaurant(3)
            {
                Name = "Zao Asian Cafe",
                Addr = "1352 State St",
                Dish = "The Bowls",
                Phone = "801-224-0030",
                Link = "www.zaoasiancafe.com"
            };
            Restaurant r4 = new Restaurant(4)
            {
                Name = "Blaze Pizza",
                Addr = "1350 S State St",
                Phone = "801-528-9501",
                Link = "www.blazepizza.com"
            };
            Restaurant r5 = new Restaurant(5)
            {
                Name = "Chick-fil-a",
                Addr = "484 Bulldog Ln",
                Phone = "801-374-2697",
                Link = "chick-fil-a.com"
            };

            return new Restaurant[] { r1, r2, r3, r4, r5 };
        }

    }
}
