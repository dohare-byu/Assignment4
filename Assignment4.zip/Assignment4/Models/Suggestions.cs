﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Models
{
    public class Suggestions
    {
        public string Name { get; set; }
        public string RestName { get; set; }
        public string? Dish { get; set; } = "It's all tasty!";
        public string? Phone { get; set; }
    }
}
