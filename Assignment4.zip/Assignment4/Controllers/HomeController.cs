﻿using Assignment4.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<string> restList = new List<string>();

            foreach(Restaurant r in Restaurant.GetRestaurants())
            {
                restList.Add($"#{r.Ranking}: {r.Name} <br> Best Dish: {r.Dish} <br>Address: {r.Addr} <br> Phone Number: {r.Phone} <br> Website: <a href='https://{r.Link}'>{r.Link}</a> <br><br>");
            }

            return View(restList);
        }
        [HttpGet]
        public IActionResult Suggest()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Suggest(Suggestions suggestions)
        {
            TempStorage.AddSuggestion(suggestions);
            return View("confirmation");
        }
        public IActionResult allSuggestions()
        {
            return View(TempStorage.Suggestions);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
